
document.getElementById('aForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('aOK').style.display = 'block';
  this.reset();
});
document.getElementById('bForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('bOK').style.display = 'block';
  this.reset();
});
